#!/bin/bash

direc01=test/direc01
direc02=test/direc02

while true; do
	DATE='date +%Y%m%d'
	HOUR='date +%H'
	mkdir $direc02/"$DATE"
	while [ $HOUR -ne "00" ]; do
	   DESTDIR=$direc02/"$DATE"/"$HOUR"
           mkdir "$DESTDIR"
           mv $direc02/*.txt "$DESTDIR"/
           sleep 3600
           HOUR='date +%H'
        done
done
