#!/bin/bash

#2022-03-24 Yujiye
#multiple signal handlers

trap 'echo 1' 1
trap 'echo 2' 2
echo $$

while true; do
	echo -n
	sleep 1
done

