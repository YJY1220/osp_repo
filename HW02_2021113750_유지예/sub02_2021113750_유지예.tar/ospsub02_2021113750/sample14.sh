#!/bin/bash
#2022-03-24 Yujiye
#hadling signals

echo $$
trap 'echo dont interrupt' 2

while true
do
	echo "try interrupt"
	sleep 1
done
