#!/bin/bash
#2022-03-24 Yujiye
#run signal handler once

trap 'justonce' 2
justonce(){
  echo "not yet"
  trap 2
}

while true; do
  echo -n "."
  sleep 1
done

